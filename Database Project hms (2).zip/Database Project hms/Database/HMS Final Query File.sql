﻿--Group Members--
--Hamza Atif(FA20-BSE-018)--
--Syed Abdul ur Rehman Ali Shah(FA20-BSE-025)--
--Qazi Sami ul Haq (FA20-BSE-024)--

--Our Project Hospital Management System consisted of major modules of Patient,Nurse,Doctor and Rooms--
--This is the combined Query File of all the tables gathered from every member and it contains some of the queries which were used in the project--
--Many problems were faced by the group in completing this project some where the updation and deletion of foreign keys which were coming from parent which
--caused many irregularities and some problems were displaying data of all generalized table in parallel which caused a lot of problems and
--was solved with the help of instructor.All the problems faced were solved coordinately in a group and teamwork resulted in the completion.
--Queries are combined together and are written below in a executable manner and is not commented.




use hospital;


Create Table Admin(
	Userid varchar(50) Unique,
	Pass varchar(50)
);
Insert into Admin(Userid,Pass)
Values ('Hamza','Hamza123')

CREATE TABLE Persons (
    PersonID int NOT NULL,
    FirstName varchar(255) NOT NULL,
	Address varchar(255) NOT NULL,
    PhoneNumber varchar(50) NOT NULL,
    PRIMARY KEY (PersonID)
);
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (1,'Michael Shawn','Karachi','03014732141')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (2,'Christopher April','Lahore','03015732139')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (3,'Jessica Derek','Faisalabad','03016732133')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (4,'Matthew Kathryn','Rawalpindi','03017732132')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (5,'Ashley Kristin','Gujranwala','03018732125')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (6,'Jennifer Chad','Peshawar','03019732119')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (7,'Joshua Jenna','Multan','03020732113')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (8,'Amanda Tara','Hyderabad','03021732104')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (9,'Daniel Maria','Islamabad','03022732098')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (10,'David Krystal','Quetta','03023732093')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (101,'James Jared','Bahawalpur','03024732085')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (102,'Robert Anna','Sargodha','03025732076')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (103,'John Edward','Sialkot','03026732069')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (104,'Joseph Julie','Sukkur','03027732066')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (105,'Andrew Peter','Larkana','03028732062')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (106,'Ryan Holly','Rahim Yar Khan','03029732058')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (107,'Brandon Marcus','Sheikhupura','03030732049')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (108,'Jason Kristina','Jhang','03031732039')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (109,'Justin Natalie','Dera Ghazi Khan','03032732036')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (110,'Sarah Jordan','Gujrat','03033732033')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (111,'William Victoria','Sahiwal','03034732026')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (112,'Jonathan Jacqueline','Wah Cantonment','03035732025')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (113,'Stephanie Corey','Mardan','03036732021')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (114,'Brian Keith','Kasur','03037732018')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (115,'Nicole Monica','Okara','03038732014')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (116,'Nicholas Juan','Mingora','03039732010')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (117,'Anthony Donald','Nawabshah','03040732009')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (118,'Heather Cassandra','Chiniot','03041731999')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (119,'Eric Meghan','Kotri','03042731989')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (120,'Elizabeth Joel','Kāmoke','03043731986')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (201,'Adam Shane','Hafizabad','03044731976')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (202,'Megan Phillip','Sadiqabad','03045731969')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (203,'Melissa Patricia','Mirpur Khas','03046731962')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (204,'Kevin Brett','Burewala','03047731955')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (205,'Steven Ronald','Kohat','03048731947')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (206,'Thomas Catherine','Khanewal','03049731940')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (207,'Timothy George','Dera Ismail Khan','03050731931')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (208,'Christina Antonio','Turbat','03051731925')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (209,'Kyle Cynthia','Muzaffargarh','03052731918')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (210,'Rachel Stacy','Abbotabad','03053731916')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (211,'Laura Kathleen','Mandi Bahauddin','03054731906')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (212,'Lauren Raymond','Shikarpur','03055731900')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (213,'Amber Carlos','Jacobabad','03056731891')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (214,'Brittany Brandi','Jhelum','03057731886')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (215,'Danielle Douglas','Khanpur','03058731885')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (216,'Richard Nathaniel','Khairpur','03059731884')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (217,'Kimberly Ian','Khuzdar','03060731877')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (218,'Jeffrey Craig','Pakpattan','03061731869')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (219,'Amy Brandy','Hub','03062731868')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (220,'Crystal Alex','Daska','03334107241')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (221,'Michelle Valerie','Gojra','03335107231')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (222,'Tiffany Veronica','Dadu','03336107229')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (223,'Jeremy Cory','Muridke','03337107223')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (224,'Benjamin Whitney','Bahawalnagar','03338107221')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (225,'Mark Gary','Samundri','03339107220')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (226,'Emily Derrick','Tando Allahyar','03340107216')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (227,'Aaron Philip','Tando Adam','03341107213')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (228,'Charles Luis','Jaranwala','03342107212')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (229,'Rebecca Diana','Chishtian','03343107207')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (230,'Jacob Chelsea','Muzaffarabad','03344107201')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (231,'Stephen Leslie','Attock','03345107198')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (232,'Patrick Caitlin','Vehari','03346107194')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (233,'Sean Leah','Kot Abdul Malik','03347107190')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (234,'Erin Natasha','Ferozwala','03348107186')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (235,'Zachary Erika','Chakwal','03349107183')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (236,'Jamie Casey','Gujranwala Cantonment','03350107174')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (237,'Kelly Latoya','Kamalia','03351107168')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (238,'Samantha Erik','Umerkot','03352107162')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (239,'Nathan Dana','Ahmedpur East','03353107154')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (240,'Sara Victor','Kot Addu','03354107147')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (241,'Dustin Brent','Wazirabad','03355107143')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (242,'Paul Dominique','Mansehra','03356107140')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (243,'Angela Frank','Layyah','03357107131')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (244,'Tyler Brittney','Mirpur','03358107129')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (245,'Scott Evan','Swabi','03359107125')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (246,'Katherine Gabriel','Chaman','03360107116')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (247,'Andrea Julia','Taxila','03361107111')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (248,'Gregory Candice','Nowshera','03362107101')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (249,'Erica Karen','Khushab','03363107100')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (250,'Mary Melanie','Shahdadkot','03364107099')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (251,'Travis Adrian','Mianwali','03365107090')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (252,'Lisa Stacey','Kabal','03366107082')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (253,'Kenneth Margaret','Lodhran','03367107080')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (254,'Bryan Sheena','Hasilpur','03368107075')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (255,'Lindsey Wesley','Charsadda','03369107068')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (256,'Kristen Vincent','Bhakkar','03370107059')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (257,'Jose Alexandra','Badin','03371107051')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (258,'Alexander Katrina','Arif Wala','03372107043')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (259,'Jesse Bethany','Ghotki','03373107037')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (260,'Katie Nichole','Sambrial','03374107032')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (261,'Lindsay Larry','Jatoi','03375107022')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (262,'Shannon Jeffery','Haroonabad','03376107019')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (263,'Vanessa Curtis','Daharki','03377107016')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (264,'Courtney Carrie','Narowal','03378107014')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (265,'Christine Todd','Tando Muhammad Khan','03379107010')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (266,'Alicia Blake','Kamber Ali Khan','03380107008')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (267,'Cody Christian','Mirpur Mathelo','03381107007')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (268,'Allison Randy','Kandhkot','03382107000')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (269,'Bradley Dennis','Bhalwal','03383106998')
Insert into Persons(PersonID,FirstName,Address,PhoneNumber) Values (270,'Samuel Alison','Gwadar','03202227656')

CREATE TABLE Doctor(
	PersonID int Primary key NOT NULL,	
	Specialization varchar(255) NOT NULL,
	FOREIGN KEY(PersonID) REFERENCES Persons(PersonID) ON DELETE CASCADE
);
Insert into Doctor(PersonID,Specialization)
Values(1,'Eye Specialist'),
(2,'Neurology'),
(3,'Psychiatry'),
(4,'Dermatology'),
(5,'Obstetrics'),
(6,'ENT Specialist'),
(7,'Allergy and immunology'),
(8,'Ophthalmology'),
(9,'Urology'),
(10,'Orthopedic');

CREATE TABLE Patient(
	PersonID int Primary key NOT NULL,
	FOREIGN KEY(PersonID) REFERENCES Persons(PersonID)ON DELETE CASCADE
);
Insert into Patient(PersonID)Values (201)
Insert into Patient(PersonID)Values (202)
Insert into Patient(PersonID)Values (203)
Insert into Patient(PersonID)Values (204)
Insert into Patient(PersonID)Values (205)
Insert into Patient(PersonID)Values (206)
Insert into Patient(PersonID)Values (207)
Insert into Patient(PersonID)Values (208)
Insert into Patient(PersonID)Values (209)
Insert into Patient(PersonID)Values (210)
Insert into Patient(PersonID)Values (211)
Insert into Patient(PersonID)Values (212)
Insert into Patient(PersonID)Values (213)
Insert into Patient(PersonID)Values (214)
Insert into Patient(PersonID)Values (215)
Insert into Patient(PersonID)Values (216)
Insert into Patient(PersonID)Values (217)
Insert into Patient(PersonID)Values (218)
Insert into Patient(PersonID)Values (219)
Insert into Patient(PersonID)Values (220)
Insert into Patient(PersonID)Values (221)
Insert into Patient(PersonID)Values (222)
Insert into Patient(PersonID)Values (223)
Insert into Patient(PersonID)Values (224)
Insert into Patient(PersonID)Values (225)
Insert into Patient(PersonID)Values (226)
Insert into Patient(PersonID)Values (227)
Insert into Patient(PersonID)Values (228)
Insert into Patient(PersonID)Values (229)
Insert into Patient(PersonID)Values (230)
Insert into Patient(PersonID)Values (231)
Insert into Patient(PersonID)Values (232)
Insert into Patient(PersonID)Values (233)
Insert into Patient(PersonID)Values (234)
Insert into Patient(PersonID)Values (235)
Insert into Patient(PersonID)Values (236)
Insert into Patient(PersonID)Values (237)
Insert into Patient(PersonID)Values (238)
Insert into Patient(PersonID)Values (239)
Insert into Patient(PersonID)Values (240)
Insert into Patient(PersonID)Values (241)
Insert into Patient(PersonID)Values (242)
Insert into Patient(PersonID)Values (243)
Insert into Patient(PersonID)Values (244)
Insert into Patient(PersonID)Values (245)
Insert into Patient(PersonID)Values (246)
Insert into Patient(PersonID)Values (247)
Insert into Patient(PersonID)Values (248)
Insert into Patient(PersonID)Values (249)
Insert into Patient(PersonID)Values (250)
Insert into Patient(PersonID)Values (251)
Insert into Patient(PersonID)Values (252)
Insert into Patient(PersonID)Values (253)
Insert into Patient(PersonID)Values (254)
Insert into Patient(PersonID)Values (255)
Insert into Patient(PersonID)Values (256)
Insert into Patient(PersonID)Values (257)
Insert into Patient(PersonID)Values (258)
Insert into Patient(PersonID)Values (259)
Insert into Patient(PersonID)Values (260)
Insert into Patient(PersonID)Values (261)
Insert into Patient(PersonID)Values (262)
Insert into Patient(PersonID)Values (263)
Insert into Patient(PersonID)Values (264)
Insert into Patient(PersonID)Values (265)
Insert into Patient(PersonID)Values (266)
Insert into Patient(PersonID)Values (267)
Insert into Patient(PersonID)Values (268)
Insert into Patient(PersonID)Values (269)
Insert into Patient(PersonID)Values (270)

CREATE TABLE Nurse(
	PersonID int Primary key NOT NULL,
	FOREIGN KEY(PersonID) REFERENCES Persons(PersonID)ON DELETE CASCADE
);

Insert into Nurse(PersonID)Values (101)
Insert into Nurse(PersonID)Values (102)
Insert into Nurse(PersonID)Values (103)
Insert into Nurse(PersonID)Values (104)
Insert into Nurse(PersonID)Values (105)
Insert into Nurse(PersonID)Values (106)
Insert into Nurse(PersonID)Values (107)
Insert into Nurse(PersonID)Values (108)
Insert into Nurse(PersonID)Values (109)
Insert into Nurse(PersonID)Values (110)
Insert into Nurse(PersonID)Values (111)
Insert into Nurse(PersonID)Values (112)
Insert into Nurse(PersonID)Values (113)
Insert into Nurse(PersonID)Values (114)
Insert into Nurse(PersonID)Values (115)
Insert into Nurse(PersonID)Values (116)
Insert into Nurse(PersonID)Values (117)
Insert into Nurse(PersonID)Values (118)
Insert into Nurse(PersonID)Values (119)
Insert into Nurse(PersonID)Values (120)

CREATE TABLE Disease(
	DiseaseID int NOT NULL,
	name varchar(255) NOT NULL,
	PRIMARY KEY(DiseaseID),
);
Insert into Disease(DiseaseID,name)
Values(501,'Migrane');
Insert into Disease(DiseaseID,name)
Values(502,'Refractive Errors'),(503,'Age-Related Macular Degeneration'),(504,'Cataract'),(505,'Diabetic Retinopathy'),
(506,'Glaucoma'),(507,'Amblyopia'),(508,'Strabismus'),(509,'Eyestrain'),(510,'Refractive Errors'),(511,'Night Blindness [Nyctalopia]'),
(512,'Conjunctivitis [Allergic / bacterial / Viral]'),(513,'Retina disorders'),(514,'Blepharitis'),(515,'Acute Spinal Cord Injury'),
(516,'Alzheimers Disease'),(517,'Amyotrophic Lateral Sclerosis (ALS)'),(518,'Bells Palsy'),(519,'Dementias'),(520,'Personality disorders.'),
(521,'Post-traumatic stress disorder.'),(522,'Eating disorders.'),(523,'Depression'),
(524,'bipolar disorder'),(525,'schizophrenia.'),(526,'eczema.'),(527,'psoriasis'),(528,'acne'),(529,'rosacea'),
(530,'ichthyosis.'),(531,'vitiligo'),(532,'hives.'),(533,'seborrheic dermatitis.'),(534,'abruptio placentae.'),
(535,'abortion'),(536,'Asherman syndrome'),(537,'diabetes and pregnancy'),(538,'ectopic pregnancy.'),(539,'haemolytic disease of the newborn.'),
(540,'labour and its abnormalities.'),(541,'large for dates'),(542,'autoimmune inner ear disease.'),(543,'cholesteatomas'),
(544,'cochlear/acoustic nerve disorders.'),(545,'conductive hearing loss.'),(546,'congenital malformations.'),
(547,'diseases of the parathyroid glands.'),(548,'Allergic asthma.'),(549,'Anaphylaxis.'),(550,'Angioedema.'),(551,'Atopic dermatitis.'),
(552,'Celiac disease.'),(553,'Macular Degeneration'),(554,'Strabismus'),(555,' Retinopathy'),(556,'Kidney Infection (Pyelonephritis'),
(557,'Kidney Stones.'),(558,'Kidney Stones in children'),(559,'Medical Tests for Prostate Problems.'),(560,'Perineal Injury in Males.'),
(561,'Osteoarthritis'),(562,'Carpal Tunnel Syndrome'),(563,'Ligament Injuries to the Knee. Torn Meniscus.'),(564,'Cubital Tunnel Syndrome');

CREATE TABLE PatientDisease(
	PersonID int NOT NULL,
	DiseaseID int NOT NULL,
	FOREIGN KEY(PersonID) REFERENCES Patient(PersonID)ON DELETE CASCADE,
	FOREIGN KEY(DiseaseID) REFERENCES Disease(DiseaseID)ON DELETE CASCADE
);
Insert into PatientDisease(PersonID,DiseaseID)Values (201,501)
Insert into PatientDisease(PersonID,DiseaseID)Values (202,502)
Insert into PatientDisease(PersonID,DiseaseID)Values (203,503)
Insert into PatientDisease(PersonID,DiseaseID)Values (204,504)
Insert into PatientDisease(PersonID,DiseaseID)Values (205,505)
Insert into PatientDisease(PersonID,DiseaseID)Values (206,506)
Insert into PatientDisease(PersonID,DiseaseID)Values (207,507)
Insert into PatientDisease(PersonID,DiseaseID)Values (208,508)
Insert into PatientDisease(PersonID,DiseaseID)Values (209,509)
Insert into PatientDisease(PersonID,DiseaseID)Values (210,510)
Insert into PatientDisease(PersonID,DiseaseID)Values (211,511)
Insert into PatientDisease(PersonID,DiseaseID)Values (212,512)
Insert into PatientDisease(PersonID,DiseaseID)Values (213,513)
Insert into PatientDisease(PersonID,DiseaseID)Values (214,514)
Insert into PatientDisease(PersonID,DiseaseID)Values (215,515)
Insert into PatientDisease(PersonID,DiseaseID)Values (216,516)
Insert into PatientDisease(PersonID,DiseaseID)Values (217,517)
Insert into PatientDisease(PersonID,DiseaseID)Values (218,518)
Insert into PatientDisease(PersonID,DiseaseID)Values (219,519)
Insert into PatientDisease(PersonID,DiseaseID)Values (220,520)
Insert into PatientDisease(PersonID,DiseaseID)Values (221,521)
Insert into PatientDisease(PersonID,DiseaseID)Values (222,522)
Insert into PatientDisease(PersonID,DiseaseID)Values (223,523)
Insert into PatientDisease(PersonID,DiseaseID)Values (224,524)
Insert into PatientDisease(PersonID,DiseaseID)Values (225,525)
Insert into PatientDisease(PersonID,DiseaseID)Values (226,526)
Insert into PatientDisease(PersonID,DiseaseID)Values (227,527)
Insert into PatientDisease(PersonID,DiseaseID)Values (228,528)
Insert into PatientDisease(PersonID,DiseaseID)Values (229,529)
Insert into PatientDisease(PersonID,DiseaseID)Values (230,530)
Insert into PatientDisease(PersonID,DiseaseID)Values (231,531)
Insert into PatientDisease(PersonID,DiseaseID)Values (232,532)
Insert into PatientDisease(PersonID,DiseaseID)Values (233,533)
Insert into PatientDisease(PersonID,DiseaseID)Values (234,534)
Insert into PatientDisease(PersonID,DiseaseID)Values (235,535)
Insert into PatientDisease(PersonID,DiseaseID)Values (236,536)
Insert into PatientDisease(PersonID,DiseaseID)Values (237,537)
Insert into PatientDisease(PersonID,DiseaseID)Values (238,538)
Insert into PatientDisease(PersonID,DiseaseID)Values (239,539)
Insert into PatientDisease(PersonID,DiseaseID)Values (240,540)
Insert into PatientDisease(PersonID,DiseaseID)Values (241,541)
Insert into PatientDisease(PersonID,DiseaseID)Values (242,542)
Insert into PatientDisease(PersonID,DiseaseID)Values (243,543)
Insert into PatientDisease(PersonID,DiseaseID)Values (244,544)
Insert into PatientDisease(PersonID,DiseaseID)Values (245,545)
Insert into PatientDisease(PersonID,DiseaseID)Values (246,546)
Insert into PatientDisease(PersonID,DiseaseID)Values (247,547)
Insert into PatientDisease(PersonID,DiseaseID)Values (248,548)
Insert into PatientDisease(PersonID,DiseaseID)Values (249,549)
Insert into PatientDisease(PersonID,DiseaseID)Values (250,550)
Insert into PatientDisease(PersonID,DiseaseID)Values (251,551)
Insert into PatientDisease(PersonID,DiseaseID)Values (252,552)
Insert into PatientDisease(PersonID,DiseaseID)Values (253,553)
Insert into PatientDisease(PersonID,DiseaseID)Values (254,554)
Insert into PatientDisease(PersonID,DiseaseID)Values (255,555)
Insert into PatientDisease(PersonID,DiseaseID)Values (256,556)
Insert into PatientDisease(PersonID,DiseaseID)Values (257,557)
Insert into PatientDisease(PersonID,DiseaseID)Values (258,558)
Insert into PatientDisease(PersonID,DiseaseID)Values (259,559)
Insert into PatientDisease(PersonID,DiseaseID)Values (260,560)
Insert into PatientDisease(PersonID,DiseaseID)Values (261,561)
Insert into PatientDisease(PersonID,DiseaseID)Values (262,562)
Insert into PatientDisease(PersonID,DiseaseID)Values (263,563)
Insert into PatientDisease(PersonID,DiseaseID)Values (264,564)
Insert Into PatientDisease(PersonID,DiseaseID)
Values (265,545),(266,554),(267,543),(268,555),(269,532),(270,511);

CREATE TABLE PatientDoctor(
	Pat_id int,
	Doc_id int,
	FOREIGN KEY(Pat_id) REFERENCES Patient(PersonID),
	FOREIGN KEY(Doc_id) REFERENCES Doctor(PersonID),
);
Insert into PatientDoctor(Pat_id,Doc_id)
Values(201,2);
Insert into PatientDoctor(Pat_id,Doc_id)
Values(202,1),(203,1),(204,1),(205,1),(206,1),(207,1),(208,1),(209,1),(210,1),(211,1),(212,1),(213,1),(214,2),(215,2),(216,2),(217,2),(218,2),(219,3),
(220,3),(221,3),(222,3),(223,3),(224,3),(225,4),(225,4),(226,4),(227,4),(228,4),(229,4),(230,4),(231,4),(232,4),(233,5),(234,5),(235,5),(236,5),(237,5),(238,5),(239,5),
(240,5),(241,6),(241,6),(242,6),(243,6),(244,6),(245,6),(246,6),(247,7),(248,7),(249,7),(250,7),(251,7),(252,8),(253,8),(254,8),(255,9),(256,9),(257,9),(258,9),(259,9),
(260,10),(261,10),(262,10),(263,10),(264,6),(265,8),(266,6),(267,8),(268,4),(269,1),(270,10)


Create Table NurseDuty (
	DutyHour int,
	PersonID int,
	FOREIGN KEY(PersonID) REFERENCES Nurse(PersonID)ON DELETE CASCADE
	)
	Insert into NurseDuty(DutyHour,PersonID)
	Values(8,101),(10,102),(12,103),(11,104),(8,105),(8,106),(12,107),(18,108),(7,109),(5,110),(8,111),(10,112),(8,113),(8,114),(8,115),(8,116),(8,117),(8,118),(8,119),
	(12,120);

Create Table DoctorDuty (
	DutyHour int,
	PersonID int,
	FOREIGN KEY(PersonID) REFERENCES Doctor(PersonID)ON DELETE CASCADE
	)
	Insert into DoctorDuty(DutyHour,PersonID)
	Values(8,1),(12,2),(10,3),(14,4),(9,5),(15,6),(7,7),(5,8),(3,9),(2,10);

Create table Room(
	Room_status varchar(50),
	Room_number varchar(50) NOT NULL,
	PRIMARY KEY(Room_number)
	);
	Insert into Room(Room_status,Room_number)
	Values('Occupied','A12'),('Occupied','A13'),('Occupied','A14'),('Occupied','A15'),('Occupied','A16'),('Occupied','A17'),('Occupied','A18'),('Occupied','A19'),
	('Occupied','A20'),('Occupied','A21'),('Occupied','A22'),('Occupied','A23'),('Occupied','A24'),('Occupied','A25'),('Occupied','A26'),('Occupied','A27'),
	('Occupied','A28'),('Occupied','A29'),('Occupied','A30'),('Occupied','A31'),('Occupied','A32'),('EMPTY','A33'),('EMPTY','A34'),('EMPTY','A35'),
	('EMPTY','A36'),('EMPTY','A37'),('EMPTY','A38'),('EMPTY','A39'),('EMPTY','A340'),('EMPTY','A41'),('EMPTY','A42'),('EMPTY','A43'),
	('EMPTY','A44'),('EMPTY','A45'),('EMPTY','A46'),('EMPTY','A47'),('EMPTY','A48'),('EMPTY','A49'),('EMPTY','A501');

	Create table Alloted_rooms(
	Pat_id int,
	Nurse_id int,
	Doc_id int,
	Room_number varchar(50) NOT NULL,
	FOREIGN KEY(Pat_id) REFERENCES Patient(PersonID),
	FOREIGN KEY(Nurse_id) REFERENCES Nurse(PersonID),
	FOREIGN KEY(Doc_id) REFERENCES Doctor(PersonID),
	FOREIGN KEY(Room_number) REFERENCES Room(Room_number)ON DELETE CASCADE
);

Insert into Alloted_rooms(Pat_id,Nurse_id,Doc_id,Room_number)
Values(201,101,2,'A13'),(202,102,2,'A14'),(203,103,4,'A15'),(204,104,7,'A16'),(205,105,9,'A17'),
(206,106,5,'A18'),(207,107,10,'A19'),(208,108,10,'A20'),
(209,109,1,'A21'),(210,110,1,'A22'),(211,111,3,'A23'),
(212,112,4,'A24'),(247,113,7,'A25'),(258,114,8,'A26'),
(243,115,8,'A27'),(237,116,6,'A28'),(269,117,10,'A29'),
(259,118,9,'A30'),(229,119,4,'A31'),(270,120,1,'A32');


--Query for All Patient Data:

Select D.PersonID [Patient ID],D.FirstName [Patient Name],D.Address,D.PhoneNumber,P.PersonID [Doctor ID],P.FirstName [Doctor Name],Di.DiseaseID [Disease ID],Di.name [Disease Name] 
from Persons P, PatientDoctor PD, Persons D ,Disease Di,PatientDisease
where P.PersonID = PD.Doc_id and D.PersonID = PD.Pat_id and PatientDisease.DiseaseID=Di.DiseaseID 
and D.PersonID=PatientDisease.PersonID

--Query For All Nurse Data:

Select Nurse.PersonID,FirstName,Address,PhoneNumber,DutyHour 
from Persons,Nurse,NurseDuty
where Nurse.PersonID=Persons.PersonID  AND NurseDuty.PersonID=Persons.PersonID

--Query For Doctor Data:

Select Doctor.PersonID,FirstName,Address,PhoneNumber,Specialization,DutyHour 
from Persons,Doctor,DoctorDuty 
where Doctor.PersonID=Persons.PersonID  AND DoctorDuty.PersonID=Persons.PersonID

--Query For Room data:

Select AR.Room_number,Room_status,P.FirstName [Patient Name],D.FirstName [Doctor Name],N.FirstName[Nurse Name] from Room R,Alloted_rooms AR,Persons P,Persons D,Persons N
where AR.Pat_id=P.PersonID AND AR.Doc_id=D.PersonID AND AR.Nurse_id=N.PersonID AND AR.Room_number=R.Room_number 


Select Room_number,Room_status from Room where Room_status='Empty'

--Delete and update Queries:

Update PatientDoctor Set Doc_id=4 where Pat_id=32

Update PatientDisease Set DiseaseID=105 where PersonID=32

Delete from PatientDoctor where Doc_id=4 
Delete from Alloted_rooms where Doc_id=4
Delete from Persons where PersonID=4

Delete from Persons where PersonID=31
Delete from Alloted_rooms where Pat_id=31
Delete from PatientDoctor  where Pat_id=31

Delete from Persons where PersonID=25
Delete from Alloted_rooms where Nurse_id=25
Update Alloted_rooms Set 
Select FirstName from Persons,Patient where Patient.PersonID=Persons.PersonID AND PersonID=205

--Random Queries:

Select FirstName from Persons,Patient where Patient.PersonID=Persons.PersonID AND Patient.PersonID=205
Select Room_status from Room where Room.Room_number='A12'
Select name from Disease where DiseaseID=505
Select FirstName from Doctor,Persons where Doctor.PersonID=Persons.PersonID and Doctor.PersonID=5