/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication41;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;

/**
 *
 * @author syed
 */
public class JavaApplication41 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try{
           System.out.println("intry");
           Connection conn = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=hospital;user=sa;password=123456;encrypt=true;trustServerCertificate=true;");
           Statement st = conn.createStatement();
                System.out.println("Connected");
        }
        
        catch(SQLException e) {
                System.out.println("in catch   "+e);;
        }
    }
    
}
